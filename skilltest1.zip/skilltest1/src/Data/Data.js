const Data = [
    {
        id: 1,
        name: "basicAnswer",
        Option: ["Yes", "Probably not"]
    }
];
export default Data;